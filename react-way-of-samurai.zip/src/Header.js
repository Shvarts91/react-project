import React from 'react';

const Header = () => {
  return (<div>
    <a href='#s'>Home</a> - 
    <a href='#s'>News Feed</a> - 
    <a href='#s'>Messages</a> - 
  </div>);
}

export default Header;