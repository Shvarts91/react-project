import React from 'react';

const Footer = () => {
  return (<div>
   it-kamasutra.com footer
  </div>);
}

export default Footer;