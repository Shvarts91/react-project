import preloader from '../../../assets/images/preloader.gif'
import React from 'react'

const Preloder = () => {
  return (
    <div>
      <img src={preloader} />
    </div>
  )
}

export default Preloder
