import React from 'react'
import { Field, Form, Formik } from 'formik'

const LoginForm = (props) => {
  return (
    <Formik
      initialValues={{
        login: '',
        password: '',
        remember: false,
      }}
      onSubmit={(values) => {
        console.log(values)
      }}
    >
      {(form) => {
        return (
          <Form>
            <div>
              <Field component={'input'} name="login" placeholder={'Login'} />
            </div>
            <div>
              <Field type="password" name="password" placeholder={'Password'} />
            </div>
            <div>
              <Field name="remember" type={'checkbox'} /> remember me
            </div>
            <div>
              <button
                // onClick={() => {
                //  form.resetForm()
                // }}
                type="submit"
              >
                Login
              </button>
            </div>
          </Form>
        )
      }}
    </Formik>
  )
}

const Login = () => {
  return (
    <div>
      <h1>LOGIN</h1>
      <LoginForm />
    </div>
  )
}

export default Login
